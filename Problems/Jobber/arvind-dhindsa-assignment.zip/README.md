# Set up
## 1. run `npm install`
## 2. run `npm run test`
